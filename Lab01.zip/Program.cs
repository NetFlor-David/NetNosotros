﻿namespace Lab01
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.Write("Hola Mundo!");
        }
    }
}
